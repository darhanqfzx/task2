package kz.bitlab.springboot.springbootdemo.lab1;

import java.util.*;

public class eighth {
    public static void main(String[] args) {
        int[] arr = new Random().ints(1000, 1, 1001).toArray();
        int start = (int) System.currentTimeMillis();
        sort(arr);
        int end = (int) System.currentTimeMillis();
        System.out.println("Time: " + (end - start) + " ms");
    }
    static void sort(int[] a) {
        for (int i = 0; i < a.length - 1; i++)
            for (int j = 0; j < a.length - i - 1; j++)
                if (a[j] > a[j + 1]) {
                    int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
                }
    }
}


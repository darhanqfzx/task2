package kz.bitlab.springboot.springbootdemo.lab1;

import java.util.Arrays;

public class fourth {
    public static void main(String[] args) {
        int[] myArray = {34, 3, 31, 98, 92, 23};
        for (int i = 0; i < myArray.length; i++) {
            for (int j = 0; j < myArray.length - 1; j++) {
                if (myArray[j] < myArray[j + 1]) {
                    int temp = myArray[j];
                    myArray[j] = myArray[j + 1];
                    myArray[j + 1] = temp;
                }
            }
        }
        System.out.println("Sorted array: " + Arrays.toString(myArray));
    }
}


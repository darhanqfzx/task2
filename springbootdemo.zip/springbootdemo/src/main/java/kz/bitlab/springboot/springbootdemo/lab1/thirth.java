package kz.bitlab.springboot.springbootdemo.lab1;

import java.util.Arrays;

public class thirth {
    public static void bubbleSortColumns(int[][] arr) {
        int rows = arr.length;
        int cols = arr[0].length;
        for (int col = 0; col < cols; col++) {
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < rows - i - 1; j++) {
                    if (arr[j][col] > arr[j + 1][col]) {
                        int temp = arr[j][col];
                        arr[j][col] = arr[j + 1][col];
                        arr[j + 1][col] = temp;
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        int[][] myArray = {
                {5, 1, 9},
                {8, 7, 2},
                {3, 4, 6}
        };
        bubbleSortColumns(myArray);
        System.out.println("Sorted array:");
        for (int[] row : myArray) {
            System.out.println(Arrays.toString(row));
        }
    }
}

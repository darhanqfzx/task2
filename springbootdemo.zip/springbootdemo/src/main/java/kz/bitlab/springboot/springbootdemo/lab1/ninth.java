package kz.bitlab.springboot.springbootdemo.lab1;

public class ninth {
    public static void main(String[] args) {
        int[] a = {12, 11, 13, 5, 6};
        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0; j < a.length - i - 1; j++)
                if (a[j] > a[j + 1]) {
                    int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
                }
            System.out.print("Pass " + (i + 1) + ": ");
            for (int n : a) System.out.print(n + " ");
            System.out.println();
        }
    }
}


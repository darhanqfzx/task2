package kz.bitlab.springboot.springbootdemo.lab1;

public class tenth {
    public static void main(String[] args) {
        int[] a1 = {1, 2, 3, 4, 5}, a2 = {5, 3, 1, 2, 4};
        System.out.println(isSorted(a1));
        System.out.println(isSorted(a2));
    }
    static boolean isSorted(int[] a) {
        for (int i = 0; i < a.length - 1; i++)
            if (a[i] > a[i + 1])
                return false;
        return true;
    }
}


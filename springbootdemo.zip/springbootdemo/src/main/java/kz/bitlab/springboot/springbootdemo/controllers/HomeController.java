package kz.bitlab.springboot.springbootdemo.controllers;

import kz.bitlab.springboot.springbootdemo.entities.Items;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {

    private List<Items> items = new ArrayList<>();

    public HomeController() {
        items.add(new Items(1L, "Laptop", "Powerful gaming laptop", 2500.0));
        items.add(new Items(2L, "Smartphone", "Latest Android phone", 1200.5));
        items.add(new Items(3L, "Headphones", "Noise-cancelling headphones", 350.0));
    }
    @GetMapping("/")
    public String indexPage(Model model) {
        model.addAttribute("tovary", items);
        return "index";
    }
    @GetMapping("/add")
    public String addProductForm(Model model) {
        model.addAttribute("item", new Items());
        return "add";
    }
    @PostMapping("/add")
    public String saveProduct(@ModelAttribute("item") Items item) {
        item.setId((long) (items.size() + 1)); 
        items.add(item);
        return "redirect:/";
    }
}

package kz.bitlab.springboot.springbootdemo.lab1;

import java.util.Random;
import java.util.Arrays;

public class fifth {
    public static void main(String[] args) {
        int[] arr = new int[1000];
        Random r = new Random();
        for (int i = 0; i < arr.length; i++) arr[i] = r.nextInt(1000) + 1;
        long start = System.currentTimeMillis();
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
        long end = System.currentTimeMillis();
        System.out.println("Time: " + (end - start) / 1000.0 + "s");
        System.out.println(Arrays.toString(arr));
    }
}

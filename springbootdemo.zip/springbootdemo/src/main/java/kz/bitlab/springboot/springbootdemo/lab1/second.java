package kz.bitlab.springboot.springbootdemo.lab1;

import java.util.Arrays;

public class second {
    public static void main(String[] args) {
        String[] arr = {"narxoz", "almaty", "bubble", "encapsulation"};
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        System.out.println("Sorted array: " + Arrays.toString(arr));
        System.out.println("B".compareTo("a"));
    }
}

